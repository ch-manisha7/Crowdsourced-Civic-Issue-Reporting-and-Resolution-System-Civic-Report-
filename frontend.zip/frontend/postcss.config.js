export default {
  plugins: {
    "@tailwindcss/postcss": {}, // ✅ Use new PostCSS plugin for Tailwind v4
    autoprefixer: {},
  },
}
