import React, { useState, useEffect } from "react";
import axios from "axios";
import { motion } from "framer-motion";
import { Sun, Moon, CheckCircle, Clock } from "lucide-react";

export default function AdminDashboard() {
  const [reports, setReports] = useState([]);
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem("darkMode") === "true";
  });

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    const res = await axios.get("http://127.0.0.1:5000/issues");
    setReports(res.data);
  };

  const updateStatus = async (id, status) => {
    await axios.post(`http://127.0.0.1:5000/update_status/${id}`, { status });
    fetchReports();
  };

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
    localStorage.setItem("darkMode", darkMode);
  }, [darkMode]);

  return (
    <div className={`min-h-screen p-6 ${darkMode ? "bg-gray-900" : "bg-gray-100"} transition-all`}>
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <h1 className={`text-3xl font-bold ${darkMode ? "text-white" : "text-gray-800"}`}>
          🛠 Admin Dashboard
        </h1>
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="p-2 rounded-full shadow-md bg-gray-200 dark:bg-gray-700 hover:scale-105 transition"
        >
          {darkMode ? <Sun className="text-yellow-400" /> : <Moon className="text-gray-800" />}
        </button>
      </div>

      {/* Reports Table */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {reports.length === 0 ? (
          <p className={`text-center ${darkMode ? "text-gray-400" : "text-gray-600"}`}>
            No reports available.
          </p>
        ) : (
          reports.map((report) => (
            <motion.div
              key={report.id}
              whileHover={{ scale: 1.02 }}
              className={`rounded-2xl shadow-lg p-4 border ${
                darkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
              }`}
            >
              {/* Image */}
              {report.image && (
                <img
                  src={`http://127.0.0.1:5000/${report.image}`}
                  alt="Issue"
                  className="w-full h-40 object-cover rounded-xl mb-3"
                />
              )}

              <p className={`text-sm mb-2 ${darkMode ? "text-gray-300" : "text-gray-700"}`}>
                {report.description}
              </p>
              <p className={`text-xs mb-2 ${darkMode ? "text-gray-400" : "text-gray-600"}`}>
                📍 {report.location}
              </p>

              <p className="text-xs font-semibold">
                🏷 Category: <span className="text-blue-500">{report.category}</span>
              </p>
              <p className="text-xs font-semibold mb-3">
                🏢 Department: <span className="text-green-500">{report.department}</span>
              </p>

              {/* Status Buttons */}
              <div className="flex gap-2">
                <button
                  onClick={() => updateStatus(report.id, "Resolved")}
                  className="flex items-center gap-1 px-3 py-1 bg-green-500 text-white text-xs rounded-lg hover:bg-green-600"
                >
                  <CheckCircle size={14} /> Resolve
                </button>
                <button
                  onClick={() => updateStatus(report.id, "Pending Verification")}
                  className="flex items-center gap-1 px-3 py-1 bg-yellow-500 text-white text-xs rounded-lg hover:bg-yellow-600"
                >
                  <Clock size={14} /> Pending
                </button>
              </div>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}

